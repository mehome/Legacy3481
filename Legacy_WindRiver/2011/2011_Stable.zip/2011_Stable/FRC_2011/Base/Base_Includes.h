#ifndef BASE_INCLUDES_H_
#define BASE_INCLUDES_H_

typedef long long __int64;
#include <string>
#include <list>
#include <vector>
#include <map>
#include <assert.h>

#endif /*BASE_INCLUDES_H_*/
