
One of the things I should point out is that all the cpp files here will include just the common files that they need.  This is due to the idea that
windriver is a slow compiler and I do not understand if it supports precompiled headers (it looks like they may call it indexing)
