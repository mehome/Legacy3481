// Copyright (c) National Instruments 2008.  All Rights Reserved.
// Do Not Edit... this file is generated!

#ifndef __nAD9A5591CC64E4DF756D77D1B57A549E_DMAChannelDescriptors_h__
#define __nAD9A5591CC64E4DF756D77D1B57A549E_DMAChannelDescriptors_h__

#include "tDMAChannelDescriptor.h"

namespace nFPGA
{
namespace nAD9A5591CC64E4DF756D77D1B57A549E
{

   static const int g_DmaVersion = 1;
   static const int g_NumDmaChannels = 1;
   static const tDMAChannelDescriptor g_DMAChannelDescriptors[] =
   {
      // "DMA"
      {
         0,
         0x00007F9C,
         1024,
         1
      },
   };

}
}

#endif // __nAD9A5591CC64E4DF756D77D1B57A549E_DMAChannelDescriptors_h__
