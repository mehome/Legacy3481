// Copyright (c) National Instruments 2008.  All Rights Reserved.
// Do Not Edit... this file is generated!

#ifndef __nAD9A5591CC64E4DF756D77D1B57A549E_ExpectedFPGASignature_h__
#define __nAD9A5591CC64E4DF756D77D1B57A549E_ExpectedFPGASignature_h__

namespace nFPGA
{
namespace nAD9A5591CC64E4DF756D77D1B57A549E
{

   static const unsigned short g_ExpectedFPGAVersion = 2010;
   static const unsigned int g_ExpectedFPGARevision = 0x00103000;
   static const unsigned int g_ExpectedFPGASignature[] = 
   {
      0xAD9A5591,
      0xCC64E4DF,
      0x756D77D1,
      0xB57A549E,
   };

}
}

#endif // __nAD9A5591CC64E4DF756D77D1B57A549E_ExpectedFPGASignature_h__
